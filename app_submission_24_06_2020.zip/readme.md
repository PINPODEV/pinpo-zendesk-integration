# Pinpo

This app contains all marketing information for Zendesk marketplace listing.

* manifest
* assets
* french and english translations
